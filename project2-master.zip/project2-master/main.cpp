#include <iostream>
#include <fstream>
#include "Token.h"
#include "Lexer.h"
#include "Parser.h"

int main(int argc, char* argv[]) {
    Lexer lex = Lexer();

    std::string fileName = argv[1];
    std::ifstream inputFile;
    std::string fileContents;

    inputFile.open(fileName, std::fstream ::in);
    if(inputFile.is_open()){
        while(inputFile.peek() != EOF) {
            fileContents.push_back(static_cast<char>(inputFile.get()));
        }
        if (inputFile.peek() == EOF){
            fileContents.push_back(inputFile.get());
        }
    } else {
    }

    lex.run(fileContents);
    
    Parser parser = Parser(lex.getTokens());

    try{
        DatalogProgram program = parser.parse();
        std::cout << "Success!" << std::endl;
        std::cout << program.toString();
    } catch (int e) {
        std::cout << "Failure!" << std::endl;
        std::cout << "  " + parser.getCurrentToken()->toString() << std::endl;
    }
    return 0;
}
