#pragma once
#include <string>

class Parameter {
public:
    Parameter(){

    };

    virtual std::string toString() = 0;
};
