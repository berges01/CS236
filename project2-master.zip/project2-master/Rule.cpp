#include "Rule.h"
std::string Rule::toString(){
    std::string result = "";
    result += (headPredicate->toString() + " :- ");
    for (int i = 0; i < int(predicates.size()); i++){
        result += predicates[i]->toString();
        if(i < int(predicates.size()) - 1){
            result += ",";
        } else {
            result += ".";
        }
    }

    return result;
};

void Rule::setPredicates(std::vector<Predicate*> predicates){
    this->predicates = predicates;
};
void Rule::setHeadPredicate(Predicate* head){
    this->headPredicate = head;
};
