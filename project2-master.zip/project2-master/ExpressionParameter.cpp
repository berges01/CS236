#include "ExpressionParameter.h"

std::string ExpressionParameter::toString(){
    return "(" + leftArg + " " + operand + " " + rightArg + ")";
};