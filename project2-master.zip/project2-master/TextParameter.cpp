#include "TextParameter.h"
std::string TextParameter::toString(){
    return data;
};