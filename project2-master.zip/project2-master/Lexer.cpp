#include "Lexer.h"

 void Lexer::run(std::string input) {
    int lineNumber = 1;

    // While there are more characters to tokenize
    while (input.size() > 0) {
        int maxRead = 0;
        Automaton* maxAutomation = automatas[0];

        //Check for spaces and new lines between characters
        while(isspace(input[0])){
            if(input[0] == '\n'){
                lineNumber += 1;
	    }

            input.erase(0,1);
        }
        for (Automaton* automaton : automatas) {
                int inputRead = automaton->Read(input);
                if (inputRead > maxRead) {
                    maxRead = inputRead;
                    maxAutomation = automaton;
                }
        }
        // Here is the "Max" part of the algorithm
        if (maxRead > 0) {
            //Update line count
            Token* newToken = maxAutomation->CreateToken(input.substr(0,maxRead), lineNumber);
            lineNumber += maxAutomation->NewLinesRead();

            if(newToken->getType() != COMMENT){
                tokens.push_back(newToken);
            }
        } else {
            maxRead = 1;

            std::string firstChar = "";
            firstChar.push_back(input[0]);
            Token* newToken;

            if(input[0] == -1){
                newToken = new Token(ENDOFFILE, "", lineNumber);
            } else {
                newToken = new Token(UNDEFINED, firstChar, lineNumber);
            }

            tokens.push_back(newToken);
        }
        input.erase(0, maxRead);
    }
}

void Lexer::print() {
    for(Token* token: tokens){
        std::cout << token->toString() << std::endl;
    }

    std::cout << "Total Tokens = " << tokens.size() << std::endl;
}

std::vector<Token *> Lexer::getTokens(){
    return this->tokens;
};
