# project-0
This program takes information about different books and stores the books in a library where they are organized according to genre and author.

Each book must have a title and an author. It can also have a genre, the number of pages in the book, and the number of hours it took to read.

The library organizes each book according to author and genre. It then prints out the title and author of each book in the different categories as well as some basic statistics such as the total number of pages and hours for each category.
