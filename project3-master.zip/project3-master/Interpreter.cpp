#include "Interpreter.h"

Interpreter::Interpreter(DatalogProgram& inProgram)
{
	dlCode = inProgram;
}

void Interpreter::CreateDatabase()
{
	CreateRelations();
	CreateTuples();
}

void Interpreter::CreateRelations()
{
	Scheme tempScheme;
	for (size_t i = 0; i < dlCode.GetSchemes().size(); ++i)
	{
		for (size_t j = 0; j < dlCode.GetSchemes().at(i).GetParams().size(); ++j)
		{
			tempScheme.push_back(dlCode.GetSchemes().at(i).GetParams().at(j).ToStr());
		}
		Relation newRelation(dlCode.GetSchemes().at(i).GetID(), tempScheme);
		allData[dlCode.GetSchemes().at(i).GetID()] = newRelation;
	}
}

void Interpreter::CreateTuples()
{
	for (size_t i = 0; i < dlCode.GetFacts().size(); ++i)
	{
		Tuple tempTuple;
		for (size_t j = 0; j < dlCode.GetFacts().at(i).GetParams().size(); ++j)
		{
			tempTuple.push_back(dlCode.GetFacts().at(i).GetParams().at(j).ToStr());
		}
		string tempName = dlCode.GetFacts().at(i).GetID();
		allData.at(tempName).AddTuple(tempTuple);
	}
}

void Interpreter::EvaluateAllQueries()
{
	Relation tempRelation;
	for (size_t i = 0; i < dlCode.GetQueries().size(); ++i)
	{
		tempRelation = EvaluateQuery(dlCode.GetQueries().at(i));
		cout << dlCode.GetQueries().at(i).ToStr() << "? ";
		if (tempRelation.GetTuples().size() != 0)
		{
			cout << "Yes(" << tempRelation.GetTuples().size() << ")" << endl;
			tempRelation.ToString();
		}
		else
		{
			cout << "No" << endl;
		}
	}
}

Relation Interpreter::EvaluateQuery(Predicate& currentQuery)
{
	map<string, int> firstSeen;
	map<int, string> formatMap;
	Relation tempRelation;
	vector<int> projectIndices;
	Scheme tempScheme;
	if (allData.find(currentQuery.GetID()) != allData.end())
	{
		tempRelation = allData.at(currentQuery.GetID());
		for (size_t j = 0; j < currentQuery.GetParams().size(); ++j)
		{
			if (currentQuery.GetParams().at(j).GetIsID())
			{
				if (firstSeen.find(currentQuery.GetParams().at(j).ToStr()) != firstSeen.end())
				{
					tempRelation = tempRelation.SelectTwoIndex(firstSeen.at(currentQuery.GetParams().at(j).ToStr()), j);
				}
				else
				{
					firstSeen[currentQuery.GetParams().at(j).ToStr()] = j;
				}
			}
			else if (currentQuery.GetParams().at(j).GetIsString())
			{
				tempRelation = tempRelation.SelectConstant(j, currentQuery.GetParams().at(j).GetValue());
			}
			else
			{
			}
		}
		for (auto swapMap : firstSeen)
		{
			formatMap[swapMap.second] = swapMap.first;
		}
		for (auto builder : formatMap)
		{
			projectIndices.push_back(builder.first);
			tempScheme.push_back(builder.second);
		}
		tempRelation = tempRelation.Project(projectIndices);
		tempRelation = tempRelation.Rename(tempScheme);
	}
	else
	{
		cout << currentQuery.ToStr() << " No" << endl;
	}

	return tempRelation;
}