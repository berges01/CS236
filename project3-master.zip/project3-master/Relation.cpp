#include "Relation.h"

Relation::Relation(){}

Relation::Relation(string inName, Scheme& inScheme)
{
	name = inName;
	scheme = inScheme;
}

void Relation::AddTuple(Tuple& newTuple) 
{ 
	allTuples.insert(newTuple);
}

void Relation::ToString()
{
	for (Tuple next : allTuples)
	{
		string spacer = "  ";
		for (size_t i = 0; i < scheme.size(); ++i)
		{
			cout << spacer << scheme[i] << "=" << next[i];
			spacer = ", ";
		}
		if (scheme.size() != 0)
		{
			cout << endl;
		}
	}
}

set<Tuple> Relation::GetTuples()
{
	return allTuples;
}

string Relation::GetName()
{
	return name;
}

void Relation::ReceiveTuples(set<Tuple> inTuples)
{
	this->allTuples = inTuples;
}

Relation Relation::SelectConstant(int index, string value)
{
	Relation tempRelation(this->name, this->scheme);
	for (Tuple temp : allTuples)
	{
		if (temp.at(index) == value)
		{
			tempRelation.AddTuple(temp);
		}		
	}
	return tempRelation;
}

Relation Relation::SelectTwoIndex(int firstIndex, int secondIndex)
{
	Relation tempRelation(this->name, this->scheme);
	for (Tuple temp : allTuples)
	{
		if (temp.at(firstIndex) == temp.at(secondIndex))
		{
			tempRelation.AddTuple(temp);
		}
	}
	return tempRelation;
}

Relation Relation::Project(vector<int> projectIndices)
{
	Relation tempRelation(this->name, this->scheme);
	for (Tuple temp : allTuples)
	{
		Tuple tempTuple;
		for (size_t i = 0; i < projectIndices.size(); ++i)
		{
			tempTuple.push_back(temp.at(projectIndices.at(i)));
		}
		tempRelation.AddTuple(tempTuple);
	}
	return tempRelation;
}

Relation Relation::Rename(Scheme renameScheme)
{
	Relation tempRelation(this->name, renameScheme);
	tempRelation.ReceiveTuples(this->allTuples);
	return tempRelation;
}