#ifndef DATABASE_H
#define DATABASE_H
#include "Relation.h"
#include <map>

class Database : public map<string, Relation>
{
public:
private:
};
#endif