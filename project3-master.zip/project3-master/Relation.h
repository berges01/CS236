#ifndef RELATION_H
#define RELATION_H
#include <iostream>
#include <set>
#include "Tuple.h"
#include "Scheme.h"

class Relation
{
public:
	Relation();
	Relation(string inName, Scheme& inScheme);
	void AddTuple(Tuple& newTuple);
	void ToString();
	set<Tuple> GetTuples();
	string GetName();
	void ReceiveTuples(set<Tuple> inTuples);
	Relation SelectConstant(int index, string value);
	Relation SelectTwoIndex(int firstIndex, int secondIndex);
	Relation Project(vector<int> projectIndices);
	Relation Rename(Scheme renameScheme);
private:
	string name;
	Scheme scheme;
	set<Tuple> allTuples;
};
#endif