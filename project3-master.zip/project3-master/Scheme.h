#ifndef SCHEME_H
#define SCHEME_H
#include <vector>
#include <string>
using namespace std;

class Scheme : public vector<string>
{
public:
	Scheme() {}
};
#endif