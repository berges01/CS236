#include <fstream>
#include <string>
#include <iostream>
#include "Lexer.h"

using namespace std;

int main(int argc, char *argv[]) {
    string fileName = argv[1];
    string line;

    Lexer lex;
    lex.openFile(fileName);
    lex.toString();
    cout << "Total Tokens = " << lex.totalTokens() << endl;
    return 0;
}